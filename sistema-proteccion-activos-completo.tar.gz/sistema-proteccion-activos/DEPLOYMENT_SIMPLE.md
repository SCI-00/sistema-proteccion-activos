# 🚀 GUÍA DE DEPLOYMENT ULTRA-SIMPLE
## Sistema Listo para Subir - 10 Minutos

**Victor, TODO el código está listo. Solo sigue estos pasos:**

---

## ✅ PASO 1: SUBIR A GITHUB (5 minutos)

### Opción A: Vía Web (MÁS FÁCIL)

1. **Ir a:** https://github.com/SCI-00/sistema-proteccion-activos

2. **Si el repo NO existe:**
   - Click "New repository"
   - Name: `sistema-proteccion-activos`
   - Private: ✅
   - Click "Create repository"

3. **Subir archivos:**
   - Click: "uploading an existing file"
   - **Arrastrar TODA la carpeta** `sistema-proteccion-activos` que descargaste
   - O click "choose your files" y seleccionar todos
   - Click: "Commit changes"

4. **Esperar** que termine de subir (1-2 minutos)

---

## ✅ PASO 2: INICIALIZAR BASE DE DATOS EN SUPABASE (2 minutos)

1. **Ir a:** https://supabase.com/dashboard/project/whoiuebzxnoxryyosgfr/editor

2. **Click:** "SQL Editor" (menú izquierdo)

3. **Click:** "+ New query"

4. **Copiar TODO el contenido** del archivo `backend/init_database.sql`
   - Está en los archivos que descargaste
   - Abrir con Notepad
   - Ctrl+A → Ctrl+C

5. **Pegar** en el SQL Editor de Supabase (Ctrl+V)

6. **Click:** "Run" (▶️)

7. **Esperar 30 segundos**

8. **Verificar:**
   - Click "Table Editor"
   - Deberías ver: cedis, estados, organizaciones, eventos_seguridad, gastos, etc.
   - Si ves ~15-20 tablas: ✅ ¡Perfecto!

---

## ✅ PASO 3: OBTENER CONNECTION STRING DE SUPABASE (1 minuto)

1. **Ir a:** https://supabase.com/dashboard/project/whoiuebzxnoxryyosgfr/settings/database

2. **Buscar:** "Connection string" → "URI"

3. **Copiar** la string (se ve así):
   ```
   postgresql://postgres.whoiuebzxnoxryyosgfr:[YOUR-PASSWORD]@aws-0-us-west-1.pooler.supabase.com:6543/postgres
   ```

4. **Reemplazar `[YOUR-PASSWORD]`** con tu password de Supabase

5. **GUARDAR** esta string completa - la necesitarás en el siguiente paso

---

## ✅ PASO 4: DEPLOY EN RENDER (3 minutos)

### Backend API:

1. **Ir a:** https://dashboard.render.com/

2. **Click:** "New +" → "Web Service"

3. **Conectar GitHub:**
   - Seleccionar tu repositorio: `sistema-proteccion-activos`
   - Click "Connect"

4. **Configurar:**
   ```
   Name: proteccion-activos-api
   Region: Oregon (US West)
   Branch: main
   Root Directory: (dejar vacío)
   Runtime: Python 3
   Build Command: pip install -r backend/requirements.txt
   Start Command: cd backend && uvicorn app.main:app --host 0.0.0.0 --port $PORT
   Instance Type: Free
   ```

5. **Environment Variables** - Click "Advanced" → "Add Environment Variable":
   ```
   DATABASE_URL = [Pegar tu connection string de Supabase del Paso 3]
   SECRET_KEY = mi-super-secret-key-cambiar-123456789
   ```

6. **Click:** "Create Web Service"

7. **Esperar 5-8 minutos** mientras hace deploy

8. **Cuando diga "Live":**
   - Copiar la URL (ej: https://proteccion-activos-api.onrender.com)
   - **GUARDAR ESTA URL** - la necesitarás para el frontend

### Frontend Dashboard:

9. **Click:** "New +" → "Web Service" (otra vez)

10. **Seleccionar** el mismo repositorio

11. **Configurar:**
    ```
    Name: proteccion-activos-dashboard
    Region: Oregon (US West)
    Branch: main
    Root Directory: (dejar vacío)
    Runtime: Python 3
    Build Command: pip install -r frontend/requirements.txt
    Start Command: cd frontend && streamlit run app.py --server.port $PORT --server.address 0.0.0.0 --server.headless true
    Instance Type: Free
    ```

12. **Environment Variables:**
    ```
    API_URL = [URL del backend del paso 8]/api
    ```
    Ejemplo: `https://proteccion-activos-api.onrender.com/api`

13. **Click:** "Create Web Service"

14. **Esperar 5-8 minutos**

15. **Cuando diga "Live":**
    - Copiar la URL (ej: https://proteccion-activos-dashboard.onrender.com)
    - **ESTA ES LA URL DE TU SISTEMA** ✅

---

## ✅ PASO 5: CREAR USUARIO ADMIN (1 minuto)

1. **Ir a:** [URL de tu backend]/docs
   - Ejemplo: https://proteccion-activos-api.onrender.com/docs

2. **Buscar:** POST `/api/auth/register`

3. **Click:** "Try it out"

4. **Llenar:**
   ```json
   {
     "nombre": "Victor Manuel De La Torre",
     "email": "victor.delatorre@omnilife.com",
     "password": "TU-PASSWORD-SEGURO",
     "rol": "Administrador",
     "organizacion_id": 1
   }
   ```

5. **Click:** "Execute"

6. **Verificar:** Response Code 200

---

## ✅ PASO 6: PROBAR EL SISTEMA (1 minuto)

1. **Ir a:** La URL de tu dashboard (del Paso 4, punto 15)

2. **Login:**
   - Email: victor.delatorre@omnilife.com
   - Password: [El que pusiste en Paso 5]

3. **¡LISTO! Deberías ver el dashboard funcionando** ✅

---

## 🎯 PASO 7: MIGRAR TUS DATOS (10 minutos)

### Opción Simple:

1. **Descargar** el archivo `migrar_rapido.py` de los archivos compartidos

2. **Editar línea 8** con tu connection string de Supabase (del Paso 3)

3. **Editar líneas 11-12** con las rutas de tus archivos Excel

4. **Instalar dependencias:**
   ```bash
   pip install pandas openpyxl psycopg2-binary
   ```

5. **Ejecutar:**
   ```bash
   python migrar_rapido.py
   ```

6. **Ver progreso** - debería migrar tus 20 CEDIS y gastos

7. **Verificar en Supabase:**
   - Table Editor → cedis
   - Deberías ver tus 20 CEDIS

8. **Refrescar el dashboard** - deberías ver tus datos

---

## 🎉 ¡SISTEMA FUNCIONANDO!

**Tienes:**
- ✅ Backend API funcionando en Render
- ✅ Frontend Dashboard funcionando en Render
- ✅ Base de datos en Supabase
- ✅ Usuario admin creado
- ✅ Datos migrados (después del Paso 7)

**URLs importantes:**
- Dashboard: [Tu URL de Paso 4, punto 15]
- API: [Tu URL de Paso 4, punto 8]
- API Docs: [Tu URL de backend]/docs
- Supabase: https://supabase.com/dashboard/project/whoiuebzxnoxryyosgfr

---

## 🐛 TROUBLESHOOTING RÁPIDO

**Problema: "No se puede conectar al API"**
- Solución: Verificar que API_URL en frontend tenga la URL correcta del backend + `/api`

**Problema: "Error de base de datos"**
- Solución: Verificar que DATABASE_URL esté correcta en Render (backend)

**Problema: "No puedo hacer login"**
- Solución: Crear usuario admin primero (Paso 5)

**Problema: "El deploy falla"**
- Solución: Ver logs en Render → Buscar el error específico → Búscalo en Google o pregúntame

---

## 📞 SIGUIENTE PASO

**Para la Demo del Lunes:**
1. ✅ Completar Pasos 1-6 (sistema funcionando)
2. ✅ Completar Paso 7 (datos migrados)
3. ✅ Probar todas las páginas del dashboard
4. ✅ Reportar cualquier problema

---

**Tiempo total:** ~20 minutos  
**Dificultad:** 🟢 Fácil  
**Status:** ✅ Todo listo para deploy  

🚀 **¡Adelante, Victor!**
